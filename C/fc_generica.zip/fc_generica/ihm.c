
#include <string.h>
#include "ihm.h"
#include "pessoa.h"

int preenche_vetor_pessoas(struct pessoa * p_vet, int p_tam) {
	int _rc = 1;
	nome _nome;
	idade _idade;
	salario _salario;
	sexo _sexo;
	for (int i = 0; i < p_tam; ++i) {
		memset(_nome, '\0', TAM_NOME);
		_rc = preenche_nome(_nome);
		if ( _rc != 1) {
			return _rc;
		}

		_rc = preenche_idade(&_idade);
		if (_rc != 1) {
			return _rc;
		}

		_rc = preenche_salario(&_salario);
		if (_rc != 1) {
			return _rc;
		}

		_rc = preenche_sexo(&_sexo);
		if (_rc != 1) {
			return _rc;
		}

		_rc = inicializa_pessoa(&(p_vet[i]), _nome, _idade, _salario, _sexo);
		if (_rc != 1) {
			return _rc;
		}
	}
	return 1;
}


int preenche_nome(nome p_nome) {

	return 1;
}

int preenche_idade(idade * p_idade) {

	return 1;
}

int preenche_salario(salario * p_salario) {

	return 1;
}

int preenche_sexo(sexo * p_sexo) {

	return 1;
}


int imprime_vetor_pessoas(struct pessoa * p_vet, int p_tam) {
	for (int i = 0; i < p_tam; ++i) {
		imprime_pessoa(&(p_vet[i]));
	}
}

void imprime_pessoa(const struct pessoa * p_pessoa) {
	printf("Pessoa: nome = %s, idade = %d, salario = %lf, sexo = %s",
		p_pessoa->m_nome
		, p_pessoa->m_idade
		, p_pessoa->m_salario
		, (p_pessoa->m_sexo == MAS ? "masculino" : "feminino"));
}