#ifndef _IHM_H_
#define _IHM_H_

#include "pessoa.h"

int preenche_vetor_pessoas(struct pessoa * p_vet, int p_tam);

int preenche_nome(nome p_nome);
int preenche_idade(idade * p_idade);
int preenche_salario(salario * p_salario);
int preenche_sexo(sexo * p_sexo);

void imprime_vetor_pessoas(struct pessoa * p_vet, int p_tam);

void imprime_pessoa(const struct pessoa * p_pessoa);

#endif
