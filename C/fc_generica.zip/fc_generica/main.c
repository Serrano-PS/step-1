
#include "ihm.h"
#include "pessoa.h"

#define TAM_VET 3

int main() {
	struct pessoa vet[TAM_VET];
	int _rc = preenche_vetor_pessoas(vet, TAM_VET);
	if ( _rc != 1) {
		printf("ERRO %d", _rc);
	}


}