#include "pessoa.h"


int inicializa_pessoa(struct pessoa * p_pessoa
	, nome p_nome
	, idade p_idade
	, salario p_salario
	, sexo p_sexo) {
	if (strlen(p_nome) > TAM_NOME) {
		return -1;
	}

	if ((p_idade < 18) || (p_idade > 99)) {
		return -2;
	}

	if ((p_salario < 100) || (p_salario > 100000)) {
		return -3;
	}

	if ((p_sexo != MAS) || (p_sexo != FEM)) {
		return -4;
	}

	strcpy(p_pessoa->m_nome, p_nome);
	p_pessoa->m_idade = p_idade;
	p_pessoa->m_salario = p_salario;
	p_pessoa->m_sexo = p_sexo;

	return 1;
}


