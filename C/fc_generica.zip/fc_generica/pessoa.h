#ifndef _PESSOA_H_
#define _PESSOA_H_

#include <string.h>

#define TAM_NOME 50

#define MAS 'M'
#define FEM 'F'

typedef char nome[TAM_NOME + 1];
typedef int idade;
typedef double salario;
typedef char sexo;

struct pessoa {
	nome m_nome;
	idade m_idade;
	salario m_salario;
	sexo m_sexo;
};

/* 
retorna -1 se nome inv�lido
retorna -2 se idade inv�lida
retorna -3 se sal�rio inv�lido
retorna -4 se sexo inv�lido 
retorna 1 se ok 
*/
int inicializa_pessoa(struct pessoa * p_pessoa
	, nome p_nome
	, idade p_idade
	, salario p_salario
	, sexo p_sexo);




#endif